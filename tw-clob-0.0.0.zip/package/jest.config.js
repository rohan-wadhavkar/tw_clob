module.exports = {
  preset: "ts-jest",
};
