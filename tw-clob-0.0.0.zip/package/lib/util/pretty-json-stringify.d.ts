/** JSON.stringify's the input with two-space indentation */
export declare function prettyJsonStringify(input: unknown): string;
//# sourceMappingURL=pretty-json-stringify.d.ts.map