/** Instances of this error represent "todo"s in this application */
export declare class NotYetImplementedError extends Error {
    constructor();
}
//# sourceMappingURL=not-yet-implemented-error.d.ts.map