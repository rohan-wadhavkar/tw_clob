/** Instances of this error represent "todo"s in this application */
export class NotYetImplementedError extends Error {
  constructor() {
    super("Not yet implemented");
  }
}
